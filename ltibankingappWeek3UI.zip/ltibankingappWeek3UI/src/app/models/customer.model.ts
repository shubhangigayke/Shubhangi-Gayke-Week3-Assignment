export class Customer {
    id?: any;
    name?: string;
    age?: number;
    address?: string;
    acctype?:string;
}
